import { ImageWithFallback } from "./figma/ImageWithFallback";
import lavagem from "../../imports/triplice_lavagem.jpeg";

const steps = [
  {
    num: "1",
    title: "Primeira Lavagem",
    desc: "Lave a embalagem imediatamente após seu esvaziamento, adicionando água até 1/4 do volume.",
  },
  {
    num: "2",
    title: "Agite e Despeje",
    desc: "Tampe a embalagem, agite por 30 segundos e despeje a água no tanque de pulverização.",
  },
  {
    num: "3",
    title: "Repita mais 2 vezes",
    desc: "Repita o processo mais duas vezes. A água usada deve ir ao tanque — sem desperdício.",
  },
  {
    num: "4",
    title: "Inutilize a Embalagem",
    desc: "Após a tríplice lavagem, perfure a embalagem para impedir qualquer reutilização indevida.",
  },
];

export function TripleLavagem() {
  return (
    <section id="lavagem" className="py-24 px-4" style={{ background: "#f0f9f1" }}>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <span
            className="inline-block px-4 py-1 rounded-full text-sm mb-4"
            style={{
              background: "#1e6b3a",
              color: "#ffffff",
              fontFamily: "'Montserrat', sans-serif",
              fontWeight: 700,
              letterSpacing: "0.1em",
            }}
          >
            PROCEDIMENTO OBRIGATÓRIO
          </span>
          <h2
            style={{
              fontFamily: "'Montserrat', sans-serif",
              fontWeight: 800,
              fontSize: "clamp(1.8rem, 4vw, 2.8rem)",
              color: "#1a2e14",
              lineHeight: 1.2,
            }}
          >
            Tríplice Lavagem
          </h2>
          <p
            className="mt-4 max-w-2xl mx-auto"
            style={{
              fontFamily: "'Lato', sans-serif",
              fontSize: "1.05rem",
              color: "#4a7a52",
              lineHeight: 1.7,
            }}
          >
            A tríplice lavagem é um procedimento <strong>obrigatório por lei</strong> e
            fundamental para garantir a descontaminação das embalagens vazias de
            defensivos agrícolas.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Steps */}
          <div className="flex flex-col gap-5">
            {steps.map((step, i) => (
              <div key={step.num} className="flex gap-5 items-start">
                {/* Number + connector */}
                <div className="flex flex-col items-center shrink-0">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center text-white shrink-0"
                    style={{
                      background: "linear-gradient(135deg, #1e6b3a, #2d9b5a)",
                      fontFamily: "'Montserrat', sans-serif",
                      fontWeight: 900,
                      fontSize: "1.1rem",
                      boxShadow: "0 4px 14px rgba(30,107,58,0.35)",
                    }}
                  >
                    {step.num}
                  </div>
                  {i < steps.length - 1 && (
                    <div className="w-0.5 h-8 mt-2" style={{ background: "rgba(30,107,58,0.25)" }} />
                  )}
                </div>
                {/* Content */}
                <div className="pb-2">
                  <h4
                    style={{
                      fontFamily: "'Montserrat', sans-serif",
                      fontWeight: 700,
                      fontSize: "1rem",
                      color: "#1a2e14",
                      marginBottom: 4,
                    }}
                  >
                    {step.title}
                  </h4>
                  <p
                    style={{
                      fontFamily: "'Lato', sans-serif",
                      fontSize: "0.95rem",
                      color: "#4a7a52",
                      lineHeight: 1.65,
                    }}
                  >
                    {step.desc}
                  </p>
                </div>
              </div>
            ))}

            {/* Alert box */}
            <div
              className="mt-2 p-5 rounded-xl flex gap-3 items-start"
              style={{ background: "#fff8e1", border: "1px solid #f5a623" }}
            >
              <span style={{ fontSize: "1.4rem", lineHeight: 1 }}>⚠️</span>
              <p
                style={{
                  fontFamily: "'Lato', sans-serif",
                  fontSize: "0.92rem",
                  color: "#7a5200",
                  lineHeight: 1.65,
                }}
              >
                <strong>Atenção:</strong> Essa prática reduz significativamente os riscos
                de contaminação ambiental e facilita a reciclagem dos materiais. Não
                realize a lavagem próximo a rios, lagos ou fontes de água.
              </p>
            </div>
          </div>

          {/* Image */}
          <div className="relative rounded-2xl overflow-hidden shadow-2xl" style={{ minHeight: 440 }}>
            <ImageWithFallback
              src={lavagem}
              alt="Demonstração da tríplice lavagem de embalagens de defensivos agrícolas"
              className="w-full h-full object-cover"
              style={{ minHeight: 440 }}
            />
            <div
              className="absolute inset-0"
              style={{ background: "linear-gradient(to top, rgba(26,46,20,0.6) 0%, transparent 50%)" }}
            />
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <p
                className="text-white"
                style={{
                  fontFamily: "'Montserrat', sans-serif",
                  fontWeight: 700,
                  fontSize: "1.1rem",
                }}
              >
                🧴 Tríplice Lavagem
              </p>
              <p
                className="text-white/80 text-sm mt-1"
                style={{ fontFamily: "'Lato', sans-serif" }}
              >
                Descontaminação correta das embalagens vazias
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
