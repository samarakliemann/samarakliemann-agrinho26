import { ChevronDown } from "lucide-react";

export function Hero() {
  const scrollDown = () => {
    const el = document.querySelector("#sobre");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background image */}
      <div
        className="absolute inset-0 bg-green-900"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1560559383-338dc7faf062?w=1600&h=900&fit=crop&auto=format')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />
      {/* Gradient overlay */}
      <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, rgba(26,46,20,0.82) 0%, rgba(30,107,58,0.65) 100%)" }} />

      {/* Decorative leaf shapes */}
      <div className="absolute top-0 right-0 w-96 h-96 opacity-10">
        <svg viewBox="0 0 200 200" className="w-full h-full text-green-300 fill-current">
          <path d="M 100 10 C 60 10, 10 60, 10 100 C 10 140, 60 190, 100 190 C 140 190, 190 140, 190 100 C 190 60, 140 10, 100 10 Z" />
        </svg>
      </div>

      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        {/* Badge */}
        <div
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full mb-6 text-sm"
          style={{
            background: "rgba(245, 166, 35, 0.2)",
            border: "1px solid rgba(245, 166, 35, 0.5)",
            color: "#f5c842",
            fontFamily: "'Lato', sans-serif",
            fontWeight: 700,
            letterSpacing: "0.12em",
          }}
        >
          🌱 CONCURSO AGRINHO 2026
        </div>

        <h1
          className="text-white mb-6 leading-tight"
          style={{
            fontFamily: "'Montserrat', sans-serif",
            fontWeight: 900,
            fontSize: "clamp(2.2rem, 6vw, 4.5rem)",
            lineHeight: 1.1,
            textShadow: "0 2px 20px rgba(0,0,0,0.3)",
          }}
        >
          Produzir Mais,
          <br />
          <span style={{ color: "#7ed957" }}>Preservando o Futuro</span>
        </h1>

        <p
          className="text-white/85 max-w-2xl mx-auto mb-10"
          style={{
            fontFamily: "'Lato', sans-serif",
            fontWeight: 300,
            fontSize: "clamp(1rem, 2.5vw, 1.25rem)",
            lineHeight: 1.7,
          }}
        >
          A sustentabilidade no campo permite aumentar a produção agrícola protegendo
          o solo, a água e a biodiversidade para as futuras gerações.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={() => document.querySelector("#sobre")?.scrollIntoView({ behavior: "smooth" })}
            className="px-8 py-3.5 rounded-full text-white transition-all hover:scale-105 active:scale-95"
            style={{
              background: "linear-gradient(135deg, #1e6b3a, #2d9b5a)",
              fontFamily: "'Montserrat', sans-serif",
              fontWeight: 700,
              fontSize: "0.95rem",
              letterSpacing: "0.05em",
              boxShadow: "0 4px 20px rgba(30,107,58,0.4)",
            }}
          >
            Explorar o Tema
          </button>
          <button
            onClick={() => document.querySelector("#quiz")?.scrollIntoView({ behavior: "smooth" })}
            className="px-8 py-3.5 rounded-full transition-all hover:scale-105 active:scale-95"
            style={{
              background: "rgba(255,255,255,0.12)",
              border: "2px solid rgba(255,255,255,0.4)",
              color: "#ffffff",
              fontFamily: "'Montserrat', sans-serif",
              fontWeight: 700,
              fontSize: "0.95rem",
              letterSpacing: "0.05em",
            }}
          >
            Fazer o Quiz 🎯
          </button>
        </div>
      </div>

      {/* Scroll indicator */}
      <button
        onClick={scrollDown}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/60 hover:text-white/90 transition-colors animate-bounce"
        aria-label="Rolar para baixo"
      >
        <ChevronDown size={32} />
      </button>
    </section>
  );
}
