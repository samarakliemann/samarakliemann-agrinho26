import { ImageWithFallback } from "./figma/ImageWithFallback";
import inpevImg from "../../imports/inPEV-02-1024x683.jpg";
import { Recycle, MapPin, CheckCircle2, ArrowRight } from "lucide-react";

const benefits = [
  "Redução da poluição ambiental",
  "Preservação dos recursos naturais",
  "Diminuição de resíduos descartados",
  "Produção de novos materiais reciclados",
  "Fortalecimento da sustentabilidade no campo",
  "Compromisso com a responsabilidade ambiental",
];

const steps = [
  {
    icon: "🧴",
    title: "Realize a Tríplice Lavagem",
    desc: "Antes de qualquer descarte, a embalagem deve obrigatoriamente passar pela tríplice lavagem.",
  },
  {
    icon: "📦",
    title: "Armazene Corretamente",
    desc: "Guarde as embalagens lavadas em local adequado, longe de alimentos, água e pessoas.",
  },
  {
    icon: "🏭",
    title: "Devolva no Posto de Coleta",
    desc: "Entregue as embalagens nos postos ou centros de coleta autorizados pelo inpEV.",
  },
  {
    icon: "♻️",
    title: "Reciclagem e Economia Circular",
    desc: "As embalagens são transformadas em novos produtos, reduzindo resíduos e promovendo a economia circular.",
  },
];

export function Reciclagem() {
  return (
    <section id="reciclagem" className="py-24 px-4" style={{ background: "#ffffff" }}>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <span
            className="inline-block px-4 py-1 rounded-full text-sm mb-4"
            style={{
              background: "#dff0d8",
              color: "#1e6b3a",
              fontFamily: "'Montserrat', sans-serif",
              fontWeight: 700,
              letterSpacing: "0.1em",
            }}
          >
            DESCARTE CORRETO
          </span>
          <h2
            style={{
              fontFamily: "'Montserrat', sans-serif",
              fontWeight: 800,
              fontSize: "clamp(1.8rem, 4vw, 2.8rem)",
              color: "#1a2e14",
              lineHeight: 1.2,
            }}
          >
            Destino Correto das Embalagens
          </h2>
          <p
            className="mt-4 max-w-2xl mx-auto"
            style={{
              fontFamily: "'Lato', sans-serif",
              fontSize: "1.05rem",
              color: "#4a7a52",
              lineHeight: 1.7,
            }}
          >
            Após a tríplice lavagem, o produtor deve armazenar e devolver as embalagens
            aos postos ou centros de coleta autorizados.
          </p>
        </div>

        {/* Image + steps */}
        <div className="grid md:grid-cols-2 gap-12 items-start mb-20">
          {/* Image */}
          <div className="relative rounded-2xl overflow-hidden shadow-2xl" style={{ minHeight: 400 }}>
            <ImageWithFallback
              src={inpevImg}
              alt="Posto de recebimento de embalagens vazias inPEV"
              className="w-full h-full object-cover"
              style={{ minHeight: 400 }}
            />
            <div
              className="absolute inset-0"
              style={{ background: "linear-gradient(to top, rgba(26,46,20,0.7) 0%, transparent 55%)" }}
            />
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <div className="flex items-center gap-2 mb-1">
                <MapPin size={16} color="#7ed957" />
                <p
                  className="text-white"
                  style={{
                    fontFamily: "'Montserrat', sans-serif",
                    fontWeight: 700,
                    fontSize: "1rem",
                  }}
                >
                  Posto de Coleta inPEV
                </p>
              </div>
              <p
                className="text-white/80 text-sm"
                style={{ fontFamily: "'Lato', sans-serif" }}
              >
                Rede nacional de coleta de embalagens vazias de defensivos
              </p>
            </div>
          </div>

          {/* Steps */}
          <div className="flex flex-col gap-5">
            {steps.map((step, i) => (
              <div
                key={i}
                className="flex gap-4 items-start p-5 rounded-xl"
                style={{ border: "1px solid rgba(30,107,58,0.15)", background: "#fafff8" }}
              >
                <span style={{ fontSize: "1.8rem", lineHeight: 1, marginTop: 2 }}>{step.icon}</span>
                <div>
                  <h4
                    style={{
                      fontFamily: "'Montserrat', sans-serif",
                      fontWeight: 700,
                      fontSize: "1rem",
                      color: "#1a2e14",
                      marginBottom: 4,
                    }}
                  >
                    {step.title}
                  </h4>
                  <p
                    style={{
                      fontFamily: "'Lato', sans-serif",
                      fontSize: "0.92rem",
                      color: "#4a7a52",
                      lineHeight: 1.65,
                    }}
                  >
                    {step.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Benefits banner */}
        <div
          className="rounded-2xl p-8 md:p-12"
          style={{ background: "linear-gradient(135deg, #1a2e14 0%, #1e6b3a 100%)" }}
        >
          <div className="flex items-center gap-3 mb-8">
            <div
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{ background: "rgba(126,217,87,0.2)" }}
            >
              <Recycle size={24} color="#7ed957" />
            </div>
            <h3
              className="text-white"
              style={{
                fontFamily: "'Montserrat', sans-serif",
                fontWeight: 800,
                fontSize: "clamp(1.2rem, 3vw, 1.7rem)",
              }}
            >
              Benefícios da Reciclagem
            </h3>
          </div>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
            {benefits.map((b) => (
              <div key={b} className="flex items-start gap-3">
                <CheckCircle2 size={18} color="#7ed957" className="mt-0.5 shrink-0" />
                <p
                  style={{
                    fontFamily: "'Lato', sans-serif",
                    fontSize: "0.95rem",
                    color: "rgba(255,255,255,0.88)",
                    lineHeight: 1.5,
                  }}
                >
                  {b}
                </p>
              </div>
            ))}
          </div>

          {/* CTA */}
          <div className="mt-8 pt-8" style={{ borderTop: "1px solid rgba(255,255,255,0.15)" }}>
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <p
                style={{
                  fontFamily: "'Lato', sans-serif",
                  fontSize: "0.95rem",
                  color: "rgba(255,255,255,0.7)",
                  lineHeight: 1.6,
                }}
              >
                Esse sistema garante que as embalagens recebam o tratamento correto,
                sendo recicladas e transformadas em novos produtos.
              </p>
              <a
                href="https://www.inpev.org.br"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-6 py-3 rounded-full shrink-0 transition-all hover:scale-105"
                style={{
                  background: "#7ed957",
                  color: "#1a2e14",
                  fontFamily: "'Montserrat', sans-serif",
                  fontWeight: 700,
                  fontSize: "0.9rem",
                  textDecoration: "none",
                }}
              >
                Saiba mais <ArrowRight size={16} />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
