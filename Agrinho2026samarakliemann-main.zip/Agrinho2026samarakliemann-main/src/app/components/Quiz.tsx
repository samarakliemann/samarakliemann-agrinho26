import { useState } from "react";
import { CheckCircle2, XCircle, RotateCcw, Trophy } from "lucide-react";

const questions = [
  {
    question: "O que é a tríplice lavagem de embalagens de defensivos agrícolas?",
    options: [
      "Lavar a embalagem uma vez com água quente",
      "Lavar a embalagem três vezes, despejando a água no tanque de pulverização",
      "Mergulhar a embalagem em um rio por três dias",
      "Deixar a embalagem ao sol por três dias",
    ],
    correct: 1,
    explanation:
      "A tríplice lavagem consiste em lavar a embalagem três vezes imediatamente após seu esvaziamento, despejando a água de lavagem no tanque de pulverização para evitar desperdício e contaminação.",
  },
  {
    question: "Qual é o destino correto das embalagens após a tríplice lavagem?",
    options: [
      "Jogá-las no lixo comum",
      "Queimá-las no campo",
      "Devolvê-las aos postos ou centros de coleta autorizados",
      "Enterrá-las na propriedade",
    ],
    correct: 2,
    explanation:
      "Após a tríplice lavagem, as embalagens devem ser entregues nos postos ou centros de coleta autorizados pelo inPEV, onde serão recicladas corretamente.",
  },
  {
    question: "Qual tecnologia é usada na agricultura de precisão para aplicação de defensivos?",
    options: [
      "Apenas tratores convencionais",
      "Drones, GPS, sensores e softwares especializados",
      "Avionetas sem controle de dose",
      "Regadores manuais",
    ],
    correct: 1,
    explanation:
      "A agricultura de precisão utiliza drones, GPS, sensores e softwares especializados para monitorar e realizar aplicações mais eficientes e com menor impacto ambiental.",
  },
  {
    question: "Por que o uso inadequado de defensivos agrícolas é prejudicial?",
    options: [
      "Porque aumenta a produtividade demais",
      "Porque deixa os alimentos mais saborosos",
      "Porque pode causar danos ao meio ambiente e à saúde humana",
      "Porque torna o solo mais fértil",
    ],
    correct: 2,
    explanation:
      "O uso inadequado de defensivos pode contaminar solo, água e prejudicar a saúde das pessoas. Por isso, é fundamental seguir as recomendações técnicas e adotar práticas sustentáveis.",
  },
  {
    question: "Qual é um dos principais benefícios da reciclagem das embalagens agrícolas?",
    options: [
      "Aumento do lixo no campo",
      "Redução da poluição ambiental e produção de novos materiais",
      "Diminuição da produtividade rural",
      "Aumento do custo de produção",
    ],
    correct: 1,
    explanation:
      "A reciclagem das embalagens agrícolas reduz a poluição ambiental, preserva recursos naturais e permite a produção de novos materiais, fortalecendo a economia circular e a sustentabilidade.",
  },
  {
    question:
      "Embora o uso inadequado de defensivos agrícolas possa causar impactos ambientais, quando utilizados de acordo com as recomendações técnicas eles oferecem importantes benefícios. Qual alternativa apresenta corretamente um desses benefícios?",
    options: [
      "Eliminam completamente a necessidade de monitoramento das lavouras e de outras práticas de manejo.",
      "Garantem o aumento da produtividade agrícola ao proteger as culturas contra pragas, doenças e plantas daninhas que podem comprometer a produção de alimentos.",
      "Tornam desnecessária a adoção de práticas sustentáveis, como a agricultura de precisão e a destinação correta das embalagens.",
      "Permitem que qualquer quantidade do produto seja aplicada sem riscos ao meio ambiente.",
    ],
    correct: 1,
    explanation:
      "Quando usados corretamente, os defensivos agrícolas protegem as culturas contra pragas, doenças e plantas daninhas, garantindo maior produtividade e segurança alimentar — sem dispensar as demais práticas sustentáveis.",
  },
  {
    question:
      "Um município pretende desenvolver um programa de conscientização ambiental voltado aos produtores rurais. Qual ação teria maior impacto positivo?",
    options: [
      "Incentivar o descarte das embalagens em terrenos vazios.",
      "Promover capacitações sobre uso responsável de defensivos e destinação correta das embalagens.",
      "Permitir a reutilização das embalagens em atividades domésticas.",
      "Reduzir a fiscalização sobre práticas ambientais.",
    ],
    correct: 1,
    explanation:
      "Capacitar produtores sobre o uso responsável de defensivos e a destinação correta das embalagens é a ação com maior impacto positivo, pois combina educação ambiental com prevenção de contaminação.",
  },
  {
    question: "Qual das alternativas representa melhor o conceito de agricultura sustentável?",
    options: [
      "Produzir mais, independentemente dos impactos ambientais.",
      "Priorizar apenas o lucro da atividade agrícola.",
      "Produzir alimentos conciliando produtividade, preservação ambiental e responsabilidade social.",
      "Reduzir totalmente o uso de tecnologia nas propriedades rurais.",
    ],
    correct: 2,
    explanation:
      "Agricultura sustentável significa produzir alimentos de qualidade equilibrando produtividade, preservação dos recursos naturais e responsabilidade social — garantindo o futuro das próximas gerações.",
  },
];

export function Quiz() {
  const [current, setCurrent] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  const [answered, setAnswered] = useState(false);

  const q = questions[current];

  const handleSelect = (idx: number) => {
    if (answered) return;
    setSelected(idx);
    setAnswered(true);
    if (idx === q.correct) setScore((s) => s + 1);
  };

  const handleNext = () => {
    if (current < questions.length - 1) {
      setCurrent((c) => c + 1);
      setSelected(null);
      setAnswered(false);
    } else {
      setFinished(true);
    }
  };

  const handleRestart = () => {
    setCurrent(0);
    setSelected(null);
    setScore(0);
    setFinished(false);
    setAnswered(false);
  };

  const percent = Math.round((score / questions.length) * 100);
  const medal = percent === 100 ? "🏆" : percent >= 60 ? "🌱" : "📚";
  const message =
    percent === 100
      ? "Perfeito! Você é um especialista em agro sustentável!"
      : percent >= 60
      ? "Bom trabalho! Continue aprendendo sobre sustentabilidade!"
      : "Continue estudando! A sustentabilidade no campo precisa de você!";

  return (
    <section id="quiz" className="py-24 px-4" style={{ background: "#f0f9f1" }}>
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <span
            className="inline-block px-4 py-1 rounded-full text-sm mb-4"
            style={{
              background: "#f5a623",
              color: "#1a2e14",
              fontFamily: "'Montserrat', sans-serif",
              fontWeight: 700,
              letterSpacing: "0.1em",
            }}
          >
            🎯 QUIZ SUSTENTÁVEL
          </span>
          <h2
            style={{
              fontFamily: "'Montserrat', sans-serif",
              fontWeight: 800,
              fontSize: "clamp(1.8rem, 4vw, 2.8rem)",
              color: "#1a2e14",
              lineHeight: 1.2,
            }}
          >
            Teste seus Conhecimentos!
          </h2>
          <p
            className="mt-3"
            style={{
              fontFamily: "'Lato', sans-serif",
              fontSize: "1.05rem",
              color: "#4a7a52",
            }}
          >
            Responda as perguntas sobre agro sustentável e veja quanto você sabe.
          </p>
        </div>

        {/* Card */}
        <div
          className="rounded-2xl overflow-hidden shadow-xl"
          style={{ background: "#ffffff" }}
        >
          {!finished ? (
            <>
              {/* Progress bar */}
              <div style={{ background: "#e6f4e1", height: 6 }}>
                <div
                  style={{
                    background: "linear-gradient(90deg, #1e6b3a, #7ed957)",
                    height: "100%",
                    width: `${((current + (answered ? 1 : 0)) / questions.length) * 100}%`,
                    transition: "width 0.4s ease",
                  }}
                />
              </div>

              <div className="p-8">
                {/* Progress label */}
                <div className="flex justify-between items-center mb-6">
                  <span
                    style={{
                      fontFamily: "'Lato', sans-serif",
                      fontSize: "0.85rem",
                      color: "#4a7a52",
                      fontWeight: 700,
                    }}
                  >
                    Pergunta {current + 1} de {questions.length}
                  </span>
                  <span
                    style={{
                      fontFamily: "'Lato', sans-serif",
                      fontSize: "0.85rem",
                      color: "#1e6b3a",
                      fontWeight: 700,
                    }}
                  >
                    ✅ {score} corretas
                  </span>
                </div>

                {/* Question */}
                <h3
                  className="mb-6"
                  style={{
                    fontFamily: "'Montserrat', sans-serif",
                    fontWeight: 700,
                    fontSize: "1.15rem",
                    color: "#1a2e14",
                    lineHeight: 1.5,
                  }}
                >
                  {q.question}
                </h3>

                {/* Options */}
                <div className="flex flex-col gap-3 mb-6">
                  {q.options.map((opt, idx) => {
                    let bg = "#fafff8";
                    let border = "1px solid rgba(30,107,58,0.2)";
                    let textColor = "#1a2e14";

                    if (answered) {
                      if (idx === q.correct) {
                        bg = "#e6f4e1";
                        border = "2px solid #1e6b3a";
                        textColor = "#1e6b3a";
                      } else if (idx === selected && idx !== q.correct) {
                        bg = "#fde8ec";
                        border = "2px solid #d4183d";
                        textColor = "#d4183d";
                      }
                    } else if (selected === idx) {
                      border = "2px solid #1e6b3a";
                    }

                    return (
                      <button
                        key={idx}
                        onClick={() => handleSelect(idx)}
                        disabled={answered}
                        className="flex items-center gap-3 w-full text-left p-4 rounded-xl transition-all"
                        style={{
                          background: bg,
                          border,
                          cursor: answered ? "default" : "pointer",
                        }}
                      >
                        <span
                          className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-sm"
                          style={{
                            background: answered && idx === q.correct
                              ? "#1e6b3a"
                              : answered && idx === selected && idx !== q.correct
                              ? "#d4183d"
                              : "rgba(30,107,58,0.12)",
                            color: answered && (idx === q.correct || idx === selected)
                              ? "#fff"
                              : "#1e6b3a",
                            fontFamily: "'Montserrat', sans-serif",
                            fontWeight: 700,
                          }}
                        >
                          {String.fromCharCode(65 + idx)}
                        </span>
                        <span
                          style={{
                            fontFamily: "'Lato', sans-serif",
                            fontSize: "0.95rem",
                            color: textColor,
                            lineHeight: 1.5,
                          }}
                        >
                          {opt}
                        </span>
                        {answered && idx === q.correct && (
                          <CheckCircle2 size={18} color="#1e6b3a" className="ml-auto shrink-0" />
                        )}
                        {answered && idx === selected && idx !== q.correct && (
                          <XCircle size={18} color="#d4183d" className="ml-auto shrink-0" />
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Explanation */}
                {answered && (
                  <div
                    className="p-4 rounded-xl mb-6"
                    style={{
                      background: selected === q.correct ? "#e6f4e1" : "#fff8e1",
                      border: `1px solid ${selected === q.correct ? "#1e6b3a" : "#f5a623"}`,
                    }}
                  >
                    <p
                      style={{
                        fontFamily: "'Lato', sans-serif",
                        fontSize: "0.92rem",
                        color: "#2d4a24",
                        lineHeight: 1.65,
                      }}
                    >
                      <strong>💡 Explicação:</strong> {q.explanation}
                    </p>
                  </div>
                )}

                {/* Next button */}
                {answered && (
                  <button
                    onClick={handleNext}
                    className="w-full py-3.5 rounded-xl text-white transition-all hover:opacity-90 active:scale-98"
                    style={{
                      background: "linear-gradient(135deg, #1e6b3a, #2d9b5a)",
                      fontFamily: "'Montserrat', sans-serif",
                      fontWeight: 700,
                      fontSize: "1rem",
                      letterSpacing: "0.03em",
                    }}
                  >
                    {current < questions.length - 1 ? "Próxima Pergunta →" : "Ver Resultado 🏆"}
                  </button>
                )}
              </div>
            </>
          ) : (
            /* Results */
            <div className="p-8 md:p-12 text-center">
              <div style={{ fontSize: "4rem", lineHeight: 1, marginBottom: 16 }}>{medal}</div>
              <h3
                className="mb-2"
                style={{
                  fontFamily: "'Montserrat', sans-serif",
                  fontWeight: 900,
                  fontSize: "2rem",
                  color: "#1a2e14",
                }}
              >
                {score}/{questions.length} acertos
              </h3>
              <div
                className="inline-block px-5 py-2 rounded-full mb-4"
                style={{
                  background: percent >= 60 ? "#e6f4e1" : "#fff8e1",
                  color: percent >= 60 ? "#1e6b3a" : "#7a5200",
                  fontFamily: "'Montserrat', sans-serif",
                  fontWeight: 700,
                  fontSize: "1.1rem",
                }}
              >
                {percent}% de aproveitamento
              </div>
              <p
                className="mb-8"
                style={{
                  fontFamily: "'Lato', sans-serif",
                  fontSize: "1.05rem",
                  color: "#4a7a52",
                  lineHeight: 1.7,
                }}
              >
                {message}
              </p>

              {/* Score bar */}
              <div
                className="rounded-full overflow-hidden mb-8 mx-auto"
                style={{ background: "#e6f4e1", height: 12, maxWidth: 320 }}
              >
                <div
                  style={{
                    background: "linear-gradient(90deg, #1e6b3a, #7ed957)",
                    height: "100%",
                    width: `${percent}%`,
                    borderRadius: 9999,
                    transition: "width 1s ease",
                  }}
                />
              </div>

              <button
                onClick={handleRestart}
                className="flex items-center gap-2 mx-auto px-8 py-3.5 rounded-full text-white transition-all hover:scale-105"
                style={{
                  background: "linear-gradient(135deg, #1e6b3a, #2d9b5a)",
                  fontFamily: "'Montserrat', sans-serif",
                  fontWeight: 700,
                  fontSize: "1rem",
                  boxShadow: "0 4px 20px rgba(30,107,58,0.35)",
                }}
              >
                <RotateCcw size={18} />
                Tentar Novamente
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
