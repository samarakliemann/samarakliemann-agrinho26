import { Leaf, Heart } from "lucide-react";

export function Footer() {
  return (
    <footer
      className="py-12 px-4"
      style={{ background: "#1a2e14" }}
    >
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Brand */}
          <div className="flex items-center gap-2">
            <Leaf size={22} style={{ color: "#7ed957" }} />
            <span
              style={{
                fontFamily: "'Montserrat', sans-serif",
                fontWeight: 800,
                fontSize: "1.1rem",
                color: "#ffffff",
                letterSpacing: "0.05em",
              }}
            >
              AGRO<span style={{ color: "#7ed957" }}>SUSTENTÁVEL</span>
            </span>
          </div>

          {/* Info */}
          <div className="text-center">
            <p
              style={{
                fontFamily: "'Lato', sans-serif",
                fontSize: "0.88rem",
                color: "rgba(255,255,255,0.55)",
                lineHeight: 1.6,
              }}
            >
              Trabalho desenvolvido para o <strong style={{ color: "rgba(255,255,255,0.75)" }}>Concurso Agrinho 2026</strong>
              <br />
              Práticas Sustentáveis na Aplicação de Defensivos Agrícolas
            </p>
          </div>

          {/* Made with */}
          <div className="flex items-center gap-1.5">
            <span
              style={{
                fontFamily: "'Lato', sans-serif",
                fontSize: "0.85rem",
                color: "rgba(255,255,255,0.45)",
              }}
            >
              Feito com
            </span>
            <Heart size={14} style={{ color: "#7ed957" }} />
            <span
              style={{
                fontFamily: "'Lato', sans-serif",
                fontSize: "0.85rem",
                color: "rgba(255,255,255,0.45)",
              }}
            >
              pelo campo
            </span>
          </div>
        </div>

        {/* Divider */}
        <div
          className="my-8"
          style={{ height: 1, background: "rgba(255,255,255,0.08)" }}
        />

        {/* Bottom links */}
        <div className="flex flex-wrap justify-center gap-6">
          {["#sobre", "#tecnologia", "#lavagem", "#reciclagem", "#quiz"].map((href, i) => {
            const labels = ["Sobre", "Tecnologia", "Tríplice Lavagem", "Reciclagem", "Quiz"];
            return (
              <button
                key={href}
                onClick={() => document.querySelector(href)?.scrollIntoView({ behavior: "smooth" })}
                style={{
                  fontFamily: "'Lato', sans-serif",
                  fontSize: "0.85rem",
                  color: "rgba(255,255,255,0.45)",
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  transition: "color 0.2s",
                }}
                onMouseEnter={(e) => (e.currentTarget.style.color = "rgba(255,255,255,0.8)")}
                onMouseLeave={(e) => (e.currentTarget.style.color = "rgba(255,255,255,0.45)")}
              >
                {labels[i]}
              </button>
            );
          })}
        </div>
      </div>
    </footer>
  );
}
