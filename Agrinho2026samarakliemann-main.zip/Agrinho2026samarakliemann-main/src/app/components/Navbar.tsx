import { useState, useEffect } from "react";
import { Menu, X, Leaf } from "lucide-react";

const links = [
  { href: "#sobre", label: "Sobre" },
  { href: "#tecnologia", label: "Tecnologia" },
  { href: "#lavagem", label: "Tríplice Lavagem" },
  { href: "#reciclagem", label: "Reciclagem" },
  { href: "#quiz", label: "Quiz" },
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleNav = (href: string) => {
    setOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        background: scrolled ? "rgba(30, 107, 58, 0.97)" : "transparent",
        backdropFilter: scrolled ? "blur(8px)" : "none",
        boxShadow: scrolled ? "0 2px 20px rgba(0,0,0,0.15)" : "none",
      }}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 flex items-center justify-between h-16">
        <button
          onClick={() => handleNav("#hero")}
          className="flex items-center gap-2 text-white"
        >
          <Leaf size={22} className="text-green-300" />
          <span
            style={{
              fontFamily: "'Montserrat', sans-serif",
              fontWeight: 800,
              fontSize: "1.1rem",
              letterSpacing: "0.05em",
            }}
          >
            AGRO<span className="text-green-300">SUSTENTÁVEL</span>
          </span>
        </button>

        {/* Desktop links */}
        <ul className="hidden md:flex items-center gap-6">
          {links.map((l) => (
            <li key={l.href}>
              <button
                onClick={() => handleNav(l.href)}
                className="text-white/90 hover:text-white transition-colors text-sm tracking-wide"
                style={{ fontFamily: "'Lato', sans-serif", fontWeight: 700 }}
              >
                {l.label}
              </button>
            </li>
          ))}
        </ul>

        {/* Mobile toggle */}
        <button
          className="md:hidden text-white"
          onClick={() => setOpen(!open)}
          aria-label="Menu"
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden bg-green-900/97 px-4 pb-4">
          <ul className="flex flex-col gap-2 pt-2">
            {links.map((l) => (
              <li key={l.href}>
                <button
                  onClick={() => handleNav(l.href)}
                  className="w-full text-left text-white/90 hover:text-white py-2 border-b border-white/10 text-sm tracking-wide"
                  style={{ fontFamily: "'Lato', sans-serif", fontWeight: 700 }}
                >
                  {l.label}
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </nav>
  );
}
