import { ImageWithFallback } from "./figma/ImageWithFallback";
import droneImg from "../../imports/drone.jpeg";
import { CheckCircle2, Zap, Target, Shield } from "lucide-react";

const features = [
  { icon: Zap, title: "Alta Eficiência", desc: "Aplicação precisa que alcança áreas de difícil acesso." },
  { icon: Target, title: "Distribuição Uniforme", desc: "Controle rigoroso da quantidade aplicada em cada ponto." },
  { icon: Shield, title: "Menor Exposição", desc: "Reduz o contato dos trabalhadores com os produtos." },
  { icon: CheckCircle2, title: "Menos Desperdício", desc: "Economia de insumos e proteção ao meio ambiente." },
];

export function Tecnologia() {
  return (
    <section id="tecnologia" className="py-24 px-4" style={{ background: "#ffffff" }}>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <span
            className="inline-block px-4 py-1 rounded-full text-sm mb-4"
            style={{
              background: "#dff0d8",
              color: "#1e6b3a",
              fontFamily: "'Montserrat', sans-serif",
              fontWeight: 700,
              letterSpacing: "0.1em",
            }}
          >
            TECNOLOGIA
          </span>
          <h2
            style={{
              fontFamily: "'Montserrat', sans-serif",
              fontWeight: 800,
              fontSize: "clamp(1.8rem, 4vw, 2.8rem)",
              color: "#1a2e14",
              lineHeight: 1.2,
            }}
          >
            Tecnologia na Aplicação
          </h2>
          <p
            className="mt-4 max-w-2xl mx-auto"
            style={{
              fontFamily: "'Lato', sans-serif",
              fontSize: "1.05rem",
              color: "#4a7a52",
              lineHeight: 1.7,
            }}
          >
            A agricultura de precisão utiliza drones, GPS, sensores e softwares especializados
            para monitorar e realizar aplicações mais eficientes.
          </p>
        </div>

        {/* Content grid */}
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Features */}
          <div className="grid grid-cols-1 gap-5">
            {/* Precision agri intro card */}
            <div
              className="p-6 rounded-2xl"
              style={{ background: "linear-gradient(135deg, #e6f4e1, #c8e6c9)" }}
            >
              <h3
                className="mb-2"
                style={{
                  fontFamily: "'Montserrat', sans-serif",
                  fontWeight: 800,
                  fontSize: "1.15rem",
                  color: "#1a2e14",
                }}
              >
                🌾 Agricultura de Precisão
              </h3>
              <p
                style={{
                  fontFamily: "'Lato', sans-serif",
                  fontSize: "0.95rem",
                  color: "#2d4a24",
                  lineHeight: 1.7,
                }}
              >
                Com essas ferramentas, o produtor identifica exatamente os locais que precisam
                de tratamento, reduzindo desperdícios e minimizando os impactos ambientais,
                aumentando produtividade e sustentabilidade.
              </p>
            </div>

            {features.map(({ icon: Icon, title, desc }) => (
              <div
                key={title}
                className="flex gap-4 items-start p-5 rounded-xl"
                style={{ border: "1px solid rgba(30,107,58,0.15)", background: "#fafff8" }}
              >
                <div
                  className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0 mt-0.5"
                  style={{ background: "#1e6b3a" }}
                >
                  <Icon size={20} color="#ffffff" />
                </div>
                <div>
                  <h4
                    style={{
                      fontFamily: "'Montserrat', sans-serif",
                      fontWeight: 700,
                      fontSize: "1rem",
                      color: "#1a2e14",
                    }}
                  >
                    {title}
                  </h4>
                  <p
                    style={{
                      fontFamily: "'Lato', sans-serif",
                      fontSize: "0.92rem",
                      color: "#4a7a52",
                      lineHeight: 1.6,
                      marginTop: 2,
                    }}
                  >
                    {desc}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Drone image */}
          <div className="relative">
            <div
              className="rounded-2xl overflow-hidden shadow-2xl"
              style={{ minHeight: 420 }}
            >
              <ImageWithFallback
                src={droneImg}
                alt="Drone agrícola realizando aplicação de defensivos"
                className="w-full h-full object-cover"
                style={{ minHeight: 420 }}
              />
            </div>
            {/* Floating badge */}
            <div
              className="absolute -bottom-5 -left-5 p-4 rounded-2xl shadow-xl"
              style={{ background: "#ffffff", border: "2px solid #e6f4e1" }}
            >
              <div className="flex items-center gap-3">
                <span style={{ fontSize: "2rem" }}>🚁</span>
                <div>
                  <p
                    style={{
                      fontFamily: "'Montserrat', sans-serif",
                      fontWeight: 800,
                      fontSize: "1.1rem",
                      color: "#1e6b3a",
                      lineHeight: 1.1,
                    }}
                  >
                    Drone Agrícola
                  </p>
                  <p
                    style={{
                      fontFamily: "'Lato', sans-serif",
                      fontSize: "0.82rem",
                      color: "#4a7a52",
                    }}
                  >
                    Inovação no campo
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
