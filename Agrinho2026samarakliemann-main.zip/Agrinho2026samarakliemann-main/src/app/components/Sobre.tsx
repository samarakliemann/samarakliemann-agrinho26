import { Sprout, Droplets, Wind, Sun } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import pulverizadorImg from "../../imports/pulverizador.png.jpeg";

const pillars = [
  { icon: Sprout, label: "Solo saudável", color: "#1e6b3a" },
  { icon: Droplets, label: "Água preservada", color: "#2196f3" },
  { icon: Wind, label: "Ar limpo", color: "#26a69a" },
  { icon: Sun, label: "Energia renovável", color: "#f5a623" },
];

export function Sobre() {
  return (
    <section id="sobre" className="py-24 px-4" style={{ background: "#f7faf3" }}>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <span
            className="inline-block px-4 py-1 rounded-full text-sm mb-4"
            style={{
              background: "#dff0d8",
              color: "#1e6b3a",
              fontFamily: "'Montserrat', sans-serif",
              fontWeight: 700,
              letterSpacing: "0.1em",
            }}
          >
            AGRICULTURA E SUSTENTABILIDADE
          </span>
          <h2
            style={{
              fontFamily: "'Montserrat', sans-serif",
              fontWeight: 800,
              fontSize: "clamp(1.8rem, 4vw, 2.8rem)",
              color: "#1a2e14",
              lineHeight: 1.2,
            }}
          >
            O que é Agricultura Sustentável?
          </h2>
        </div>

        {/* Two columns */}
        <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
          {/* Image */}
          <div className="relative rounded-2xl overflow-hidden shadow-xl" style={{ minHeight: 360 }}>
            <ImageWithFallback
              src={pulverizadorImg}
              alt="Pulverizador aplicando defensivos na lavoura"
              className="w-full h-full object-cover"
              style={{ minHeight: 360 }}
            />
            <div
              className="absolute bottom-0 left-0 right-0 p-4"
              style={{ background: "linear-gradient(to top, rgba(26,46,20,0.85), transparent)" }}
            >
              <p
                className="text-white/90 text-sm"
                style={{ fontFamily: "'Lato', sans-serif", fontWeight: 300 }}
              >
                Pulverizadores aplicando defensivos na lavoura de forma controlada
              </p>
            </div>
          </div>

          {/* Text */}
          <div>
            <p
              className="mb-6"
              style={{
                fontFamily: "'Lato', sans-serif",
                fontWeight: 400,
                fontSize: "1.05rem",
                lineHeight: 1.8,
                color: "#2d4a24",
              }}
            >
              A agricultura sustentável busca produzir alimentos de qualidade sem
              comprometer os recursos naturais das futuras gerações. Esse modelo considera
              a preservação do solo, da água, da fauna e da flora, mantendo a rentabilidade
              das propriedades rurais.
            </p>
            <p
              className="mb-8"
              style={{
                fontFamily: "'Lato', sans-serif",
                fontWeight: 400,
                fontSize: "1.05rem",
                lineHeight: 1.8,
                color: "#2d4a24",
              }}
            >
              A sustentabilidade no campo depende da adoção de tecnologias modernas,
              do uso racional dos recursos naturais e da conscientização dos produtores
              sobre a importância da preservação ambiental.
            </p>

            {/* Pillars */}
            <div className="grid grid-cols-2 gap-4">
              {pillars.map(({ icon: Icon, label, color }) => (
                <div
                  key={label}
                  className="flex items-center gap-3 p-4 rounded-xl"
                  style={{ background: "#ffffff", border: "1px solid rgba(30,107,58,0.12)" }}
                >
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center shrink-0"
                    style={{ background: `${color}18` }}
                  >
                    <Icon size={18} style={{ color }} />
                  </div>
                  <span
                    style={{
                      fontFamily: "'Lato', sans-serif",
                      fontWeight: 700,
                      fontSize: "0.9rem",
                      color: "#1a2e14",
                    }}
                  >
                    {label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Defensivos box */}
        <div
          className="rounded-2xl p-8 md:p-12"
          style={{ background: "linear-gradient(135deg, #1e6b3a 0%, #2d9b5a 100%)", color: "#fff" }}
        >
          <div className="max-w-3xl mx-auto text-center">
            <h3
              className="mb-4"
              style={{
                fontFamily: "'Montserrat', sans-serif",
                fontWeight: 800,
                fontSize: "clamp(1.3rem, 3vw, 1.9rem)",
                lineHeight: 1.3,
              }}
            >
              O que são Defensivos Agrícolas?
            </h3>
            <p
              style={{
                fontFamily: "'Lato', sans-serif",
                fontWeight: 300,
                fontSize: "1.05rem",
                lineHeight: 1.8,
                color: "rgba(255,255,255,0.9)",
              }}
            >
              Os defensivos agrícolas são produtos utilizados para proteger as lavouras
              contra pragas, doenças e plantas invasoras que podem comprometer a produção
              de alimentos. Quando usados de forma correta e seguindo as recomendações
              técnicas, ajudam a garantir a produtividade das culturas e a segurança
              alimentar da população. Entretanto, seu uso inadequado pode causar danos
              ao meio ambiente e à saúde, tornando fundamental a adoção de práticas
              sustentáveis.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
