import "../styles/fonts.css";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { Sobre } from "./components/Sobre";
import { Tecnologia } from "./components/Tecnologia";
import { TripleLavagem } from "./components/TripleLavagem";
import { Reciclagem } from "./components/Reciclagem";
import { Quiz } from "./components/Quiz";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div style={{ fontFamily: "'Lato', sans-serif" }}>
      <Navbar />
      <Hero />
      <Sobre />
      <Tecnologia />
      <TripleLavagem />
      <Reciclagem />
      <Quiz />
      <Footer />
    </div>
  );
}
